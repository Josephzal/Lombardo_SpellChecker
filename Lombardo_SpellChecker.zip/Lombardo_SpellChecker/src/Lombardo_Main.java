//Author Name: Joseph Lombardo
//Date: 05/25/2021
//Program Name: Lombardo_SpellChecker
//Purpose: Check testStates file against dictionary file to verify correct spelling
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lombardo_Main {
	
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		List<String> dictionaryList = new ArrayList<>();
		List<String> testList = new ArrayList<>();
		boolean dictionaryFileExists = false;
		boolean testFileExists = false;
		// Loop to accept user input for dictionary file
		// Loop repeats until user enters an existing file
		while(!dictionaryFileExists) {
			System.out.println("Enter a file name as the dictionary:");
			File dictionary = new File(input.nextLine());
			// try block verifies that user has entered an existing
			// file, if not an exception is thrown
			try {
				// Loop through file and add to dictionaryList ArrayList
				Scanner scanner = new Scanner(dictionary);
				while(scanner.hasNextLine()) {
					dictionaryList.add(scanner.nextLine());
				}
				scanner.close();
				dictionaryFileExists = true;
			// If file doesn't exist, output error	
			}catch(FileNotFoundException e) {
				System.out.println("File not found.");
			}
		}
		// Loop to accept user input for dictionary file
		// Loop repeats until user enters an existing file
		while(!testFileExists) {
			System.out.println("Enter a file name as the test data:");		
			File testData = new File(input.nextLine());	
			// try block verifies that user has entered an existing
			// file, if not an exception is thrown
			try {
				// Loop through file and add to testList ArrayList
				Scanner scanner = new Scanner(testData);
				while(scanner.hasNextLine()) {
					testList.add(scanner.nextLine());
				}
				scanner.close();
				testFileExists = true;
			// If file doesn't exist, output error	
			}catch(FileNotFoundException e) {
				System.out.println("File not found.");
			}
		}
		input.close();
		// Loop through testList, if the current string is not found
		// in the dictionaryList, output that it's an unknown word
		for(String s : testList) {
			if(!dictionaryList.contains(s)) {
				System.out.println(s + " is an unknown word.");
			}
		}
	}
}
